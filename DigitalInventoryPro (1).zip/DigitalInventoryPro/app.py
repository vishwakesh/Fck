import streamlit as st
import pandas as pd
import os
import json
import datetime
from data_manager import DataManager
from utils import initialize_session_state, format_currency

# Page configuration
st.set_page_config(
    page_title="DigitalStock - Inventory Management",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom theme colors
primary_color = "#1a73e8"
success_color = "#28a745"
warning_color = "#ffc107"
danger_color = "#dc3545"
info_color = "#17a2b8"

# Initialize session state
initialize_session_state()

# Initialize data manager
if 'data_manager' not in st.session_state:
    st.session_state.data_manager = DataManager()

# Main dashboard page
def main():
    # Sidebar brand and navigation
    with st.sidebar:
        st.markdown(f"""
        <div style='text-align: center; padding: 10px; margin-bottom: 20px;'>
            <h2 style='color: {primary_color}'>📦 DigitalStock</h2>
            <p>Inventory Management System</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Add current date to sidebar
        today = datetime.datetime.now().strftime("%A, %B %d, %Y")
        st.markdown(f"<p style='text-align: center;'>{today}</p>", unsafe_allow_html=True)
    
    # Main dashboard header
    st.markdown("""
    <style>
    .dashboard-header {
        padding: 1rem;
        border-radius: 10px;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
    }
    .emoji-title {
        font-size: 2.5rem;
        margin-right: 0.5rem;
    }
    </style>
    <div class="dashboard-header">
        <h1>📊 DigitalStock Dashboard</h1>
        <p>Your digital product inventory management solution</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Display quick stats with nice styling
    st.markdown("""
    <style>
    .metric-container {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        padding: 1rem;
        transition: transform 0.3s;
    }
    .metric-container:hover {
        transform: translateY(-5px);
    }
    .metric-icon {
        font-size: 2rem;
        margin-bottom: 0.5rem;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Get all data for calculations
    products = st.session_state.data_manager.get_products()
    sales = st.session_state.data_manager.get_sales()
    expenses = st.session_state.data_manager.get_expenses()
    
    # Calculate key metrics
    total_revenue = sum(sale.get('amount', 0) for sale in sales)
    completed_sales = [s for s in sales if s.get('status', '') == 'Completed']
    refunded_sales = [s for s in sales if s.get('status', '') == 'Refunded']
    total_expenses = sum(expense.get('amount', 0) for expense in expenses)
    profit = total_revenue - total_expenses
    
    # Total profit from sales with profit data
    total_sales_profit = sum(sale.get('profit', 0) for sale in sales if sale.get('status', '') != 'Refunded')
    
    # Display metrics in a grid
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-icon">📦</div>
            <h3>Total Products</h3>
            <h2>{}</h2>
            <p>{} with low stock</p>
        </div>
        """.format(
            len(products), 
            len([p for p in products if p.get('quantity', 0) <= p.get('low_stock_threshold', 5)])
        ), unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-icon">💰</div>
            <h3>Total Sales</h3>
            <h2>{}</h2>
            <p>{} completed, {} refunded</p>
        </div>
        """.format(
            len(sales),
            len(completed_sales),
            len(refunded_sales)
        ), unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-icon">💵</div>
            <h3>Total Revenue</h3>
            <h2>{}</h2>
            <p>{} expenses</p>
        </div>
        """.format(
            format_currency(total_revenue),
            format_currency(total_expenses)
        ), unsafe_allow_html=True)
    
    with col4:
        profit_color = success_color if profit > 0 else danger_color
        st.markdown("""
        <div class="metric-container">
            <div class="metric-icon">📈</div>
            <h3>Net Profit</h3>
            <h2 style="color: {};">{}</h2>
            <p>Sales profit: {}</p>
        </div>
        """.format(
            profit_color,
            format_currency(profit),
            format_currency(total_sales_profit)
        ), unsafe_allow_html=True)
    
    # Dashboard tabs for organization
    dash_tab1, dash_tab2, dash_tab3 = st.tabs(["📋 Overview", "⚠️ Alerts", "❓ Help & Support"])
    
    with dash_tab1:
        # Recent sales with improved display
        st.subheader("📊 Recent Sales")
        if sales:
            recent_sales = sorted(sales, key=lambda x: x.get('date', ''), reverse=True)[:5]
            
            # Convert to DataFrame for better display
            sales_df = pd.DataFrame(recent_sales)
            if not sales_df.empty:
                # Format display columns
                display_cols = ['date', 'sale_code', 'product_id', 'quantity', 'amount', 'status']
                display_cols = [col for col in display_cols if col in sales_df.columns]
                
                # Map product IDs to names
                products_dict = {p['id']: p['name'] for p in products}
                if 'product_id' in sales_df.columns:
                    sales_df['product'] = sales_df['product_id'].map(products_dict)
                    display_cols = [col for col in display_cols if col != 'product_id']
                    display_cols.append('product')
                
                # Format currency
                if 'amount' in sales_df.columns:
                    sales_df['amount'] = sales_df['amount'].apply(lambda x: format_currency(x))
                
                # Add status indicators
                if 'status' in sales_df.columns:
                    sales_df['status'] = sales_df['status'].apply(lambda x: 
                        f"✅ {x}" if x == 'Completed' else
                        f"🔄 {x}" if x == 'Replaced' else
                        f"⛔ {x}" if x == 'Refunded' else x
                    )
                
                st.dataframe(sales_df[display_cols], use_container_width=True, height=250)
                
                view_all_sales = st.button("🔍 View All Sales")
                if view_all_sales:
                    st.switch_page("pages/2_sales.py")
        else:
            st.info("📝 No sales recorded yet. Head to the Sales tab to record your first sale!")
            
        # Recent expenses
        st.subheader("💸 Recent Expenses")
        expenses = st.session_state.data_manager.get_expenses()
        
        if expenses:
            recent_expenses = sorted(expenses, key=lambda x: x.get('date', ''), reverse=True)[:5]
            
            # Convert to DataFrame for better display
            expenses_df = pd.DataFrame(recent_expenses)
            if not expenses_df.empty:
                # Format display columns
                display_cols = ['date', 'description', 'category', 'amount']
                display_cols = [col for col in display_cols if col in expenses_df.columns]
                
                # Format currency
                if 'amount' in expenses_df.columns:
                    expenses_df['amount'] = expenses_df['amount'].apply(lambda x: format_currency(x))
                
                st.dataframe(expenses_df[display_cols], use_container_width=True, height=200)
                
                view_all_expenses = st.button("🔍 View All Expenses")
                if view_all_expenses:
                    st.switch_page("pages/4_settings.py")
        else:
            st.info("📝 No expenses recorded yet. Head to the Settings tab to record expenses.")
    
    with dash_tab2:
        # Low stock alerts with improved styling
        st.subheader("⚠️ Low Stock Alerts")
        low_stock_products = [p for p in products if p.get('quantity', 0) <= p.get('low_stock_threshold', 5)]
        
        if low_stock_products:
            low_stock_df = pd.DataFrame(low_stock_products)
            display_cols = ['name', 'quantity', 'low_stock_threshold', 'price']
            display_cols = [col for col in display_cols if col in low_stock_df.columns]
            
            # Add indicator column
            low_stock_df['status'] = low_stock_df.apply(
                lambda row: "🔴 Critical" if row['quantity'] == 0 
                else "🟠 Low" if row['quantity'] <= row['low_stock_threshold'] / 2
                else "🟡 Warning", 
                axis=1
            )
            
            # Format currency
            if 'price' in low_stock_df.columns:
                low_stock_df['price'] = low_stock_df['price'].apply(lambda x: format_currency(x))
            
            display_cols.append('status')
            
            st.dataframe(low_stock_df[display_cols], use_container_width=True)
            
            # Quick action button
            restock_button = st.button("📦 Manage Inventory")
            if restock_button:
                st.switch_page("pages/1_inventory.py")
        else:
            st.success("✅ All products have sufficient stock levels")
        
        # Expired product alerts (placeholder for future feature)
        st.subheader("📅 Product Performance Alerts")
        st.markdown("""
        <div style="padding: 1rem; background-color: #e9ecef; border-radius: 0.5rem; margin-bottom: 1rem;">
            <h4>💡 Future Feature</h4>
            <p>This section will display alerts for product performance, including:</p>
            <ul>
                <li>Products with declining sales</li>
                <li>Best-selling products trending up</li>
                <li>Seasonal product recommendations</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with dash_tab3:
        # Help & Support section
        st.subheader("❓ Help & Support")
        
        # Add collapsible sections for FAQ
        with st.expander("📋 Frequently Asked Questions"):
            st.markdown("""
            **How do I add a new product?**
            
            Go to the Inventory tab, select "Add Product" and fill in the required information including name, cost price, selling price, and quantity.
            
            **How do I record a sale?**
            
            Navigate to the Sales tab, select a product from your inventory, specify the quantity, and complete the sale form. A unique sale code will be automatically generated.
            
            **Can I export my data?**
            
            Yes! Go to the Settings tab, select Import/Export Data, and use the export buttons to download your data in CSV or JSON format.
            
            **How do I use the offline version?**
            
            Generate and download the offline version from the Dashboard or Settings page. Run the downloaded executable on your computer to access your inventory management system without an internet connection.
            """)
        
        # Support options
        st.subheader("📞 Contact Support")
        support_col1, support_col2 = st.columns(2)
        
        with support_col1:
            st.markdown("""
            ### 📧 Contact Support
            
            For technical issues or feature requests:
            
            **Email:** vishwakesh55@gmail.com
            
            **Discord:** vishwakesh2
            
            Please allow 24-48 hours for a response.
            """)
        
        with support_col2:
            st.markdown("""
            ### 💬 Community & Support
            
            Connect with other users and share tips:
            
            **Discord:** vishwakesh2
            
            **Email:** vishwakesh55@gmail.com
            
            *Get help, troubleshoot issues, and discover best practices*
            """)
            
        # Feedback form
        st.subheader("💌 Send Feedback")
        with st.form(key="feedback_form"):
            feedback_name = st.text_input("Your Name")
            feedback_email = st.text_input("Your Email")
            feedback_type = st.selectbox("Feedback Type", options=[
                "Bug Report", "Feature Request", "General Feedback", "Question"
            ])
            feedback_message = st.text_area("Your Message", height=100)
            
            submit_feedback = st.form_submit_button("📤 Send Feedback")
            
            if submit_feedback:
                if feedback_name and feedback_email and feedback_message:
                    st.success("Thank you for your feedback! We'll review it and get back to you if needed.")
                else:
                    st.error("Please fill in all required fields.")
        
    # Donation section with improved UI
    st.markdown("---")
    
    # Support This Project section with tabs for different payment methods
    st.markdown("""
    <div style="background-color: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin-top: 2rem;">
        <h3 style="text-align: center;">💝 Support This Project</h3>
        <p style="text-align: center;">Your contributions help maintain and improve DigitalStock</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create tabs for different payment methods
    pay_tab1, pay_tab2 = st.tabs(["📱 UPI Payment", "💰 Litecoin (LTC)"])
    
    with pay_tab1:
        upi_col1, upi_col2 = st.columns([3, 2])
        with upi_col1:
            st.markdown("""
            ### UPI Payment
            
            Make an instant payment using any UPI app:
            
            1. Open your UPI app (Google Pay, PhonePe, etc.)
            2. Select "Pay to UPI ID"
            3. Enter the UPI ID: **vishwakesh@fam**
            4. Enter amount and complete payment
            """)
            
            # Add a copy button that works with JavaScript
            st.markdown("""
            <div style="display: flex; align-items: center;">
                <code style="background: #f0f0f0; padding: 0.5rem; border-radius: 5px; margin-right: 0.5rem; font-size: 1.1rem;">vishwakesh@fam</code>
                <button onclick="navigator.clipboard.writeText('vishwakesh@fam'); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy', 2000)" 
                style="background-color: #5e72e4; color: white; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer;">
                Copy UPI ID
                </button>
            </div>
            """, unsafe_allow_html=True)
            
        with upi_col2:
            st.markdown("""
            <div style="background-color: white; padding: 1rem; border-radius: 10px; text-align: center; border: 1px dashed #ccc;">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/UPI-Logo-vector.svg/1200px-UPI-Logo-vector.svg.png" width="100">
                <div style="margin-top: 1rem; font-weight: bold;">vishwakesh@fam</div>
            </div>
            """, unsafe_allow_html=True)
    
    with pay_tab2:
        crypto_col1, crypto_col2 = st.columns([2, 1])
        
        with crypto_col1:
            st.markdown("""
            ### Litecoin (LTC)
            
            Send LTC to this address:
            
            ```
            ltc1qrgjan6957e5zedad88nraht98vw6g8tnneps2c
            ```
            """)
            
            # Add a copy button that works with JavaScript
            st.markdown("""
            <button onclick="navigator.clipboard.writeText('ltc1qrgjan6957e5zedad88nraht98vw6g8tnneps2c'); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy LTC Address', 2000)" 
            style="background-color: #5e72e4; color: white; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer; margin-bottom: 1rem;">
            Copy LTC Address
            </button>
            """, unsafe_allow_html=True)
            
        with crypto_col2:
            st.markdown("""
            <div style="background-color: white; padding: 1rem; border-radius: 10px; text-align: center; border: 1px dashed #ccc;">
                <img src="https://cryptologos.cc/logos/litecoin-ltc-logo.png" width="100">
            </div>
            """, unsafe_allow_html=True)
        
        # Contact info
        st.markdown("""
        For any questions about donations, please contact:
        
        **Email:** vishwakesh55@gmail.com
        
        **Discord:** vishwakesh2
        """)
        
    # Add thank you message
    st.markdown("""
    <div style="background-color: #e8f4f8; padding: 1rem; border-radius: 10px; margin-top: 1rem; text-align: center;">
        <h4>Thank You For Your Support! 💖</h4>
        <p>Your contribution helps us add more features and maintain the application.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Download offline app section with improved UI
    st.markdown("---")
    st.markdown("""
    <div style="background-color: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin-top: 1rem; margin-bottom: 2rem;">
        <h3 style="text-align: center;">💻 Download Offline Version</h3>
        <p style="text-align: center;">Use DigitalStock without an internet connection</p>
    </div>
    """, unsafe_allow_html=True)
    
    offline_col1, offline_col2 = st.columns([2, 1])
    
    with offline_col1:
        st.markdown("""
        ### 🖥️ Available for all platforms
        - Windows: Full desktop application
        - macOS: Native application with all features
        - Linux: Compatible with major distributions
        
        All data will be stored locally on your device, and you can import/export data between the web and offline versions.
        """)
        
    with offline_col2:
        # In a real application, this would be a link to a pre-built offline version
        if st.button("🚀 Generate and Download Offline Version", use_container_width=True):
            st.session_state['show_offline_download'] = True
        
        if st.session_state.get('show_offline_download', False):
            st.info("⚙️ Preparing your download... This may take a moment.")
            st.download_button(
                label="📥 Download Offline App (Demo)",
                data="This is a placeholder for the actual executable file",
                file_name="digitalstock_offline_demo.txt",
                mime="text/plain",
                use_container_width=True
            )
            st.markdown("""
            **📝 Note:** In a real deployment:
            1. The offline app would be built using PyInstaller
            2. It would include all necessary dependencies
            3. The download would be an actual executable file for your OS
            """)
            
    # Footer
    st.markdown("""
    <div style="text-align: center; margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #ddd;">
        <p>DigitalStock Inventory Management v1.0 © 2023</p>
        <p style="font-size: 0.8rem;">Made with ❤️ for digital product sellers</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
