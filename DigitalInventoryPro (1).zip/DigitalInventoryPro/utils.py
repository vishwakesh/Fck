import streamlit as st
import pandas as pd
import uuid
import datetime
import os
import json
import random
import string
import io

def initialize_session_state():
    """Initialize session state variables"""
    if 'show_offline_download' not in st.session_state:
        st.session_state['show_offline_download'] = False

def generate_id():
    """Generate a unique ID"""
    return str(uuid.uuid4())

def generate_sale_code(length=8):
    """Generate a unique sale code"""
    # Generate a random code with letters and numbers and timestamp
    timestamp = datetime.datetime.now().strftime("%y%m%d")
    chars = string.ascii_uppercase + string.digits
    random_part = ''.join(random.choice(chars) for _ in range(length-6))
    return f"{timestamp}{random_part}"

def get_current_date():
    """Get current date in YYYY-MM-DD format"""
    return datetime.datetime.now().strftime("%Y-%m-%d")

def format_currency(amount):
    """Format a number as USD currency"""
    return f"${amount:.2f}"

def calculate_profit(cost_price, selling_price, quantity=1):
    """Calculate profit from cost and selling prices"""
    unit_profit = selling_price - cost_price
    total_profit = unit_profit * quantity
    profit_margin = (unit_profit / selling_price * 100) if selling_price > 0 else 0
    return {
        'unit_profit': unit_profit,
        'total_profit': total_profit,
        'profit_margin': profit_margin
    }

def validate_product_data(data):
    """Validate product data"""
    required_fields = ['name', 'price', 'quantity']
    errors = []
    
    for field in required_fields:
        if not data.get(field):
            errors.append(f"{field.capitalize()} is required")
    
    if data.get('price') and (not isinstance(data['price'], (int, float)) or data['price'] < 0):
        errors.append("Price must be a positive number")
    
    if data.get('cost_price') and (not isinstance(data['cost_price'], (int, float)) or data['cost_price'] < 0):
        errors.append("Cost price must be a positive number")
    
    if data.get('quantity') and (not isinstance(data['quantity'], int) or data['quantity'] < 0):
        errors.append("Quantity must be a positive integer")
    
    return errors

def validate_sale_data(data, available_quantity):
    """Validate sale data"""
    errors = []
    
    if not data.get('quantity') or data['quantity'] <= 0:
        errors.append("Quantity must be greater than 0")
    
    if data.get('quantity', 0) > available_quantity:
        errors.append(f"Not enough stock available. Only {available_quantity} items in stock.")
    
    if not data.get('amount') or data['amount'] <= 0:
        errors.append("Amount must be greater than 0")
    
    return errors

def export_data_to_csv(data, filename):
    """Export data to CSV"""
    df = pd.DataFrame(data)
    return df.to_csv(index=False).encode('utf-8')

def export_data_to_excel(data_dict):
    """Export multiple datasets to Excel"""
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        for sheet_name, data in data_dict.items():
            df = pd.DataFrame(data)
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    output.seek(0)
    return output.getvalue()
