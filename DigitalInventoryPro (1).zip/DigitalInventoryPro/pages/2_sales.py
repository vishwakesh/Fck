import streamlit as st
import pandas as pd
from utils import validate_sale_data, generate_id, generate_sale_code, format_currency, calculate_profit, get_current_date
import io
import base64
import qrcode
from PIL import Image
import datetime

# Page configuration
st.set_page_config(
    page_title="Sales Management",
    page_icon="💰",
    layout="wide"
)

# Custom styles
st.markdown("""
<style>
    .card {
        padding: 1.5rem;
        border-radius: 10px;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }
    .emoji-title {
        font-size: 1.8rem;
        margin-right: 0.5rem;
    }
    .success-box {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        color: #856404;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .info-box {
        background-color: #d1ecf1;
        color: #0c5460;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .sales-confirmation {
        text-align: center;
        padding: 1.5rem;
        background-color: #d4edda;
        border-radius: 10px;
        margin-top: 1rem;
    }
    .animated-qr {
        transition: transform 0.3s;
    }
    .animated-qr:hover {
        transform: scale(1.05);
    }
</style>
""", unsafe_allow_html=True)

# Helper functions for barcodes/QR codes
def generate_qr_code(data):
    """Generate a QR code for data"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert PIL image to bytes
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    return img_str

def image_to_base64(img_bytes):
    """Convert image bytes to base64 for embedding in HTML"""
    return base64.b64encode(img_bytes).decode()

# Get data manager from session state
data_manager = st.session_state.data_manager

# Main sales page with emoji title
st.markdown("<h1>💰 Sales & Orders Management</h1>", unsafe_allow_html=True)
st.markdown("Track sales, generate receipts, and manage customer orders")

# Create tabs for different sales operations with emojis
tab1, tab2, tab3, tab4 = st.tabs(["💵 Record Sale", "📊 Sales History", "🔄 Refunds & Replacements", "🔍 Sale Code Verification"])

# Tab 1: Record Sale
with tab1:
    st.markdown("<h3>🛒 Record New Sale</h3>", unsafe_allow_html=True)
    
    # Create tabs for Sale and Add Product
    sale_tab, add_product_tab = st.tabs(["Record Sale", "➕ Add New Product"])
    
    with add_product_tab:
        st.subheader("Add New Product")
        
        with st.form(key="add_product_sales_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                name = st.text_input("Product Name")
                cost_price = st.number_input("Buy Price ($)", min_value=0.0, step=0.01)
                quantity = st.number_input("Quantity", min_value=0, step=1)
            
            with col2:
                description = st.text_area("Description")
                price = st.number_input("Sell Price ($)", min_value=0.0, step=0.01)
                low_stock_threshold = st.number_input("Low Stock Alert Threshold", min_value=1, value=5, step=1)
            
            # Show real-time profit calculation
            if cost_price > 0 and price > 0:
                profit = price - cost_price
                margin = (profit / price * 100) if price > 0 else 0
                st.info(f"Profit per unit: {format_currency(profit)} (Margin: {margin:.1f}%)")
            
            submit_button = st.form_submit_button("Add Product")
            
            if submit_button:
                new_product = {
                    'name': name,
                    'description': description,
                    'cost_price': cost_price,
                    'price': price,
                    'quantity': quantity,
                    'low_stock_threshold': low_stock_threshold
                }
                
                # Validate data
                errors = validate_product_data(new_product)
                
                if errors:
                    for error in errors:
                        st.error(error)
                else:
                    # Add product
                    if data_manager.add_product(new_product):
                        st.success("Product added successfully")
                        # Rerun to refresh product list
                        st.rerun()
                    else:
                        st.error("Failed to add product")
    
    with sale_tab:
        # Get products for selection
        products = data_manager.get_products()
        
        if not products:
            st.warning("No products in inventory. Add some products to record sales.")
        else:
            # Filter out products with zero quantity
            available_products = [p for p in products if p.get('quantity', 0) > 0]
            
            if not available_products:
                st.warning("No products with available stock. Please update your inventory.")
            else:
                product_options = {f"{p['name']} (Stock: {p['quantity']})": p['id'] for p in available_products}
            
                with st.form(key="new_sale_form"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        selected_product_display = st.selectbox("Select Product", options=list(product_options.keys()))
                        selected_product_id = product_options[selected_product_display] if selected_product_display else None
                        
                        if selected_product_id:
                            selected_product = data_manager.get_product_by_id(selected_product_id)
                            
                            # Display product details
                            if 'cost_price' in selected_product and 'price' in selected_product:
                                st.write(f"Sell Price: {format_currency(selected_product.get('price', 0))}")
                                if selected_product.get('cost_price', 0) > 0:
                                    profit_info = calculate_profit(
                                        selected_product.get('cost_price', 0), 
                                        selected_product.get('price', 0)
                                    )
                                    st.write(f"Profit per unit: {format_currency(profit_info['unit_profit'])} ({profit_info['profit_margin']:.1f}%)")
                                    st.write(f"Buy Price: {format_currency(selected_product.get('cost_price', 0))}")
                        
                        # Auto-generate sale code
                        sale_code = generate_sale_code()
                        st.text_input("Sale Code (Auto-generated)", value=sale_code, disabled=True)
                    
                    with col2:    
                        if selected_product_id:
                            max_quantity = selected_product.get('quantity', 0)
                            quantity = st.number_input("Quantity", min_value=1, max_value=max_quantity, value=1, step=1)
                            
                            # Calculate total automatically
                            unit_price = selected_product.get('price', 0)
                            total_amount = unit_price * quantity
                            st.text_input("Total Amount ($)", value=f"{total_amount:.2f}", disabled=True)
                            
                            # Customer information
                            customer_email = st.text_input("Customer Email")
                            customer_notes = st.text_area("Notes", height=100)
                            
                            # Calculate profit
                            if 'cost_price' in selected_product:
                                cost_price = selected_product.get('cost_price', 0)
                                total_cost = cost_price * quantity
                                profit = total_amount - total_cost
                                st.write(f"Total Profit: {format_currency(profit)}")
                    
                    submit_button = st.form_submit_button("Complete Sale")
                    
                    if submit_button and selected_product_id:
                        sale_data = {
                            'product_id': selected_product_id,
                            'quantity': quantity,
                            'amount': total_amount,
                            'sale_code': sale_code,
                            'customer_email': customer_email,
                            'notes': customer_notes,
                            'status': 'Completed'
                        }
                        
                        # Add cost data if available
                        if 'cost_price' in selected_product:
                            sale_data['unit_cost'] = selected_product.get('cost_price', 0)
                            sale_data['total_cost'] = sale_data['unit_cost'] * quantity
                            sale_data['profit'] = sale_data['amount'] - sale_data['total_cost']
                        
                        # Validate sale data
                        errors = validate_sale_data(sale_data, max_quantity)
                        
                        if errors:
                            for error in errors:
                                st.error(error)
                        else:
                            # Add sale
                            if data_manager.add_sale(sale_data):
                                st.success("Sale recorded successfully")
                                
                                # Display sale code and QR code
                                qr_img = generate_qr_code(sale_code)
                                st.markdown(f"""
                                ### Sale Completed Successfully!
                                **Sale Code:** {sale_code}
                                
                                **QR Code for this sale:**
                                <img src="data:image/png;base64,{qr_img}" width="200">
                                
                                *Save this code for reference and verification.*
                                """, unsafe_allow_html=True)
                            else:
                                st.error("Failed to record sale")

# Tab 2: Sales History
with tab2:
    st.subheader("Sales History")
    
    # Get sales
    sales = data_manager.get_sales()
    
    if sales:
        # Convert to DataFrame for better display
        sales_df = pd.DataFrame(sales)
        
        # Add filter options
        col1, col2, col3 = st.columns(3)
        
        with col1:
            status_filter = st.selectbox(
                "Filter by Status",
                options=["All", "Completed", "Refunded", "Replaced"]
            )
        
        with col2:
            search_term = st.text_input("Search by Sale Code or Customer Email")
        
        with col3:
            # Product filter
            products = data_manager.get_products()
            product_options = {"All Products": "all"}
            product_options.update({p['name']: p['id'] for p in products})
            
            product_filter = st.selectbox("Filter by Product", options=list(product_options.keys()))
            selected_product_id = product_options[product_filter]
        
        # Apply filters
        filtered_sales = sales
        
        if status_filter != "All":
            filtered_sales = [s for s in filtered_sales if s.get('status') == status_filter]
        
        if search_term:
            filtered_sales = [
                s for s in filtered_sales if 
                (search_term.lower() in s.get('sale_code', '').lower() or 
                 search_term.lower() in s.get('customer_email', '').lower())
            ]
        
        if selected_product_id != "all":
            filtered_sales = [s for s in filtered_sales if s.get('product_id') == selected_product_id]
        
        # Display sales table
        if filtered_sales:
            filtered_df = pd.DataFrame(filtered_sales)
            
            # Get product names
            products_dict = {p['id']: p['name'] for p in data_manager.get_products()}
            
            # Add product name column
            if 'product_id' in filtered_df.columns:
                filtered_df['product'] = filtered_df['product_id'].map(products_dict)
            
            # Format currency columns
            if 'amount' in filtered_df.columns:
                filtered_df['amount'] = filtered_df['amount'].apply(lambda x: format_currency(x))
            
            if 'profit' in filtered_df.columns:
                filtered_df['profit'] = filtered_df['profit'].apply(lambda x: format_currency(x))
            
            # Format display columns
            display_cols = ['date', 'sale_code', 'product', 'quantity', 'amount', 'profit', 'customer_email', 'status']
            display_cols = [col for col in display_cols if col in filtered_df.columns]
            
            st.dataframe(filtered_df[display_cols], use_container_width=True, height=300)
            
            # Summary statistics
            st.subheader("Sales Summary")
            stats_col1, stats_col2, stats_col3, stats_col4 = st.columns(4)
            
            with stats_col1:
                st.metric("Total Sales", len(filtered_sales))
            
            with stats_col2:
                total_amount = sum(s.get('amount', 0) for s in filtered_sales)
                st.metric("Total Revenue", format_currency(total_amount))
            
            with stats_col3:
                total_profit = sum(s.get('profit', 0) for s in filtered_sales if s.get('status') != 'Refunded')
                st.metric("Total Profit", format_currency(total_profit))
            
            with stats_col4:
                if total_amount > 0:
                    profit_margin = (total_profit / total_amount) * 100
                    st.metric("Average Profit Margin", f"{profit_margin:.1f}%")
                else:
                    st.metric("Average Profit Margin", "0%")
            
            # Sale details
            st.subheader("View Sale Details")
            
            # Select sale to view
            sale_options = {f"{s.get('sale_code', 'N/A')} - {s.get('date', 'N/A')}": s['id'] for s in filtered_sales}
            selected_sale_display = st.selectbox("Select a sale", options=list(sale_options.keys()))
            
            if selected_sale_display:
                selected_sale_id = sale_options[selected_sale_display]
                selected_sale = next((s for s in sales if s.get('id') == selected_sale_id), None)
                
                if selected_sale:
                    # Get product details
                    product = data_manager.get_product_by_id(selected_sale.get('product_id'))
                    product_name = product.get('name', 'Unknown Product') if product else 'Unknown Product'
                    
                    # Display sale details
                    details_col1, details_col2, details_col3 = st.columns([2, 2, 1])
                    
                    with details_col1:
                        st.write(f"**Sale Code:** {selected_sale.get('sale_code', 'N/A')}")
                        st.write(f"**Date:** {selected_sale.get('date', 'N/A')}")
                        st.write(f"**Product:** {product_name}")
                        st.write(f"**Quantity:** {selected_sale.get('quantity', 0)}")
                    
                    with details_col2:
                        st.write(f"**Amount:** {format_currency(selected_sale.get('amount', 0))}")
                        if 'profit' in selected_sale:
                            st.write(f"**Profit:** {format_currency(selected_sale.get('profit', 0))}")
                        st.write(f"**Customer Email:** {selected_sale.get('customer_email', 'N/A')}")
                        st.write(f"**Status:** {selected_sale.get('status', 'N/A')}")
                    
                    with details_col3:
                        # Generate and display QR code for the sale
                        sale_code = selected_sale.get('sale_code', 'N/A')
                        qr_img = generate_qr_code(sale_code)
                        st.markdown(f'<img src="data:image/png;base64,{qr_img}" width="120">', unsafe_allow_html=True)
                    
                    st.write(f"**Notes:** {selected_sale.get('notes', 'N/A')}")
        else:
            st.info("No sales match your filter criteria")
    else:
        st.info("No sales recorded yet")

# Tab 3: Refunds/Replacements
with tab3:
    st.subheader("Process Refunds & Replacements")
    
    # Get sales that are not already refunded/replaced
    sales = data_manager.get_sales()
    eligible_sales = [s for s in sales if s.get('status') == 'Completed']
    
    if eligible_sales:
        # Convert to DataFrame for display
        sales_df = pd.DataFrame(eligible_sales)
        
        # Format display columns
        if not sales_df.empty:
            # Get product names
            products_dict = {p['id']: p['name'] for p in data_manager.get_products()}
            
            # Add product name column
            if 'product_id' in sales_df.columns:
                sales_df['product'] = sales_df['product_id'].map(products_dict)
            
            # Format currency
            if 'amount' in sales_df.columns:
                sales_df['amount'] = sales_df['amount'].apply(lambda x: format_currency(x))
            
            display_cols = ['date', 'sale_code', 'product', 'quantity', 'amount', 'customer_email']
            display_cols = [col for col in display_cols if col in sales_df.columns]
            
            st.dataframe(sales_df[display_cols], use_container_width=True)
        
        # Select sale for refund/replacement
        sale_options = {f"{s.get('sale_code', 'N/A')} - {s.get('date', 'N/A')}": s['id'] for s in eligible_sales}
        selected_sale_display = st.selectbox("Select a sale for refund/replacement", options=list(sale_options.keys()))
        
        if selected_sale_display:
            selected_sale_id = sale_options[selected_sale_display]
            selected_sale = next((s for s in sales if s.get('id') == selected_sale_id), None)
            
            if selected_sale:
                # Get product details
                product = data_manager.get_product_by_id(selected_sale.get('product_id'))
                product_name = product.get('name', 'Unknown Product') if product else 'Unknown Product'
                
                # Display sale details
                details_col1, details_col2 = st.columns(2)
                
                with details_col1:
                    st.write(f"**Sale Code:** {selected_sale.get('sale_code', 'N/A')}")
                    st.write(f"**Date:** {selected_sale.get('date', 'N/A')}")
                    st.write(f"**Product:** {product_name}")
                    st.write(f"**Quantity:** {selected_sale.get('quantity', 0)}")
                
                with details_col2:
                    st.write(f"**Amount:** {format_currency(selected_sale.get('amount', 0))}")
                    st.write(f"**Customer Email:** {selected_sale.get('customer_email', 'N/A')}")
                    if 'profit' in selected_sale:
                        st.write(f"**Profit:** {format_currency(selected_sale.get('profit', 0))}")
                
                # Process refund/replacement
                action_col1, action_col2 = st.columns(2)
                
                with action_col1:
                    st.subheader("Process Refund")
                    refund_notes = st.text_area("Refund Notes", placeholder="Enter reason for refund", key="refund_notes")
                    
                    if st.button("Issue Refund"):
                        # Update sale status to Refunded
                        update_data = {
                            'status': 'Refunded',
                            'refund_date': get_current_date(),
                        }
                        
                        if refund_notes:
                            update_data['refund_notes'] = refund_notes
                        
                        if data_manager.update_sale(selected_sale_id, update_data):
                            # Return stock to inventory
                            data_manager.update_stock(selected_sale.get('product_id'), selected_sale.get('quantity', 0))
                            st.success("Refund processed successfully")
                            st.rerun()
                        else:
                            st.error("Failed to process refund")
                
                with action_col2:
                    st.subheader("Process Replacement")
                    replacement_notes = st.text_area("Replacement Notes", placeholder="Enter reason for replacement", key="replacement_notes")
                    
                    if st.button("Issue Replacement"):
                        # Update sale status to Replaced
                        update_data = {
                            'status': 'Replaced',
                            'replacement_date': get_current_date(),
                        }
                        
                        if replacement_notes:
                            update_data['replacement_notes'] = replacement_notes
                        
                        if data_manager.update_sale(selected_sale_id, update_data):
                            st.success("Replacement processed successfully")
                            st.rerun()
                        else:
                            st.error("Failed to process replacement")
    else:
        st.info("No completed sales available for refund/replacement")

# Tab 4: Sale Codes and Barcodes
with tab4:
    st.markdown("<h3>🔍 Sale Code Verification & QR Generator</h3>", unsafe_allow_html=True)
    st.markdown("Verify sales and generate QR codes for digital receipts")
    
    # Add tabs within the verification section
    verify_tab1, verify_tab2, verify_tab3 = st.tabs(["🔎 Verify Sale", "🏷️ Generate QR Code", "📱 Bulk Download"])
    
    # Tab 1: Verify Sale Code
    with verify_tab1:
        st.markdown("""
        <div class='card'>
            <h4>🧾 Verify Sale by Code</h4>
            <p>Enter a sale code to verify its authenticity and view details</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Nice search box
        sale_code_input = st.text_input(
            "Enter Sale Code", 
            placeholder="e.g., 230401ABC123",
            help="Enter the sale code provided to the customer"
        )
        
        verify_button = st.button("🔍 Verify Sale Code", type="primary", use_container_width=True)
        
        if sale_code_input and verify_button:
            # Get sales that match the code
            sales = data_manager.get_sales()
            matching_sale = next((s for s in sales if s.get('sale_code') == sale_code_input), None)
            
            if matching_sale:
                # Get product details
                product = data_manager.get_product_by_id(matching_sale.get('product_id'))
                product_name = product.get('name', 'Unknown Product') if product else 'Unknown Product'
                
                # Create a nice verification card
                status_color = "#28a745" if matching_sale.get('status') == 'Completed' else "#dc3545"
                status_emoji = "✅" if matching_sale.get('status') == 'Completed' else "⚠️"
                
                # Generate QR code
                qr_img = generate_qr_code(sale_code_input)
                
                st.markdown(f"""
                <div class="success-box" style="text-align: center; margin-top: 1rem;">
                    <h3>✅ Valid Sale Code</h3>
                    <p>This sale code has been verified in our system</p>
                </div>
                
                <div style="display: flex; margin-top: 1rem; background-color: white; padding: 1rem; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);">
                    <div style="flex: 3; padding-right: 1rem;">
                        <h4>Sale Details</h4>
                        <table style="width: 100%;">
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Sale Code:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee;">{matching_sale.get('sale_code', 'N/A')}</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Date:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee;">{matching_sale.get('date', 'N/A')}</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Product:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee;">{product_name}</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Quantity:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee;">{matching_sale.get('quantity', 0)}</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Amount:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee;">{format_currency(matching_sale.get('amount', 0))}</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Status:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; color: {status_color};">
                                    {status_emoji} {matching_sale.get('status', 'N/A')}
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; font-weight: bold;">Customer:</td>
                                <td style="padding: 8px 0;">{matching_sale.get('customer_email', 'N/A')}</td>
                            </tr>
                        </table>
                    </div>
                    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                        <div class="animated-qr">
                            <img src="data:image/png;base64,{qr_img}" width="150">
                        </div>
                        <p style="text-align: center; margin-top: 0.5rem; font-size: 0.9rem;">Verified ✓</p>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Notes section if available
                if matching_sale.get('notes'):
                    st.markdown("""
                    <div style="margin-top: 1rem; background-color: #f8f9fa; padding: 1rem; border-radius: 10px;">
                        <h4>📝 Notes</h4>
                        <p>{}</p>
                    </div>
                    """.format(matching_sale.get('notes')), unsafe_allow_html=True)
                
                # Actions for the sale
                actions_col1, actions_col2 = st.columns(2)
                with actions_col1:
                    st.download_button(
                        "⬇️ Download Receipt QR",
                        data=qr_img,
                        file_name=f"receipt_{sale_code_input}.png",
                        mime="image/png"
                    )
                
                with actions_col2:
                    if st.button("📤 Share Sale Details"):
                        st.info("Sharing functionality would be implemented in a production version.")
            else:
                st.markdown("""
                <div class="warning-box" style="text-align: center;">
                    <h3>❌ Invalid or Unknown Sale Code</h3>
                    <p>The sale code you entered was not found in our system. Please check the code and try again.</p>
                </div>
                """, unsafe_allow_html=True)
    
    # Tab 2: Generate QR Code
    with verify_tab2:
        st.markdown("""
        <div class='card'>
            <h4>🏷️ Generate QR Code for Existing Sale</h4>
            <p>Create a QR code for an existing sale to share with customers</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Get sales for selection
        sales = data_manager.get_sales()
        if sales:
            # Filter options
            search_sale = st.text_input("Search by sale code or customer email", placeholder="Enter search term")
            
            filtered_sales = sales
            if search_sale:
                filtered_sales = [
                    s for s in sales if 
                    (search_sale.lower() in s.get('sale_code', '').lower() or 
                     search_sale.lower() in s.get('customer_email', '').lower())
                ]
            
            # Format options for display
            sale_options = {
                f"{s.get('sale_code', 'N/A')} - {product_name_lookup(s.get('product_id'), data_manager)} - {s.get('date', 'N/A')}": 
                s['sale_code'] for s in filtered_sales
            }
            
            if sale_options:
                selected_sale_display = st.selectbox(
                    "Select a sale", 
                    options=list(sale_options.keys()), 
                    key="qr_sale_select"
                )
                
                if selected_sale_display:
                    selected_sale_code = sale_options[selected_sale_display]
                    matching_sale = next((s for s in sales if s.get('sale_code') == selected_sale_code), None)
                    
                    # QR Code customization
                    qr_col1, qr_col2 = st.columns(2)
                    
                    with qr_col1:
                        qr_size = st.slider("QR Code Size", min_value=5, max_value=15, value=10, step=1)
                        qr_border = st.slider("Border Size", min_value=1, max_value=5, value=4, step=1)
                    
                    with qr_col2:
                        qr_error = st.selectbox(
                            "Error Correction", 
                            options=["Low", "Medium", "High"], 
                            index=0,
                            help="Higher correction allows QR code to be readable even if partially damaged"
                        )
                        
                        # Map selection to QRCode constants
                        error_mapping = {
                            "Low": qrcode.constants.ERROR_CORRECT_L,
                            "Medium": qrcode.constants.ERROR_CORRECT_M,
                            "High": qrcode.constants.ERROR_CORRECT_H
                        }
                        error_level = error_mapping[qr_error]
                    
                    # Generate customized QR code
                    qr = qrcode.QRCode(
                        version=1,
                        error_correction=error_level,
                        box_size=qr_size,
                        border=qr_border,
                    )
                    qr.add_data(selected_sale_code)
                    qr.make(fit=True)
                    img = qr.make_image(fill_color="black", back_color="white")
                    
                    # Convert to base64 for display
                    buffered = io.BytesIO()
                    img.save(buffered, format="PNG")
                    img_bytes = buffered.getvalue()
                    img_str = base64.b64encode(img_bytes).decode()
                    
                    # Display QR code with sale information
                    if matching_sale:
                        product = data_manager.get_product_by_id(matching_sale.get('product_id'))
                        product_name = product.get('name', 'Unknown Product') if product else 'Unknown Product'
                        
                        st.markdown(f"""
                        <div style="display: flex; align-items: center; background-color: white; padding: 1rem; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); margin-top: 1rem;">
                            <div style="flex: 1; padding-right: 1rem;">
                                <h3>Sale: {selected_sale_code}</h3>
                                <p><strong>Product:</strong> {product_name}</p>
                                <p><strong>Date:</strong> {matching_sale.get('date', 'N/A')}</p>
                                <p><strong>Amount:</strong> {format_currency(matching_sale.get('amount', 0))}</p>
                            </div>
                            <div class="animated-qr" style="flex: 1; text-align: center;">
                                <img src="data:image/png;base64,{img_str}" width="100%">
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Download options
                        download_col1, download_col2 = st.columns(2)
                        
                        with download_col1:
                            st.download_button(
                                label="📥 Download QR Code",
                                data=img_bytes,
                                file_name=f"sale_code_{selected_sale_code}.png",
                                mime="image/png",
                                use_container_width=True
                            )
                        
                        with download_col2:
                            st.download_button(
                                label="📄 Download as PDF",
                                data=f"This would be a PDF receipt for sale {selected_sale_code}",
                                file_name=f"receipt_{selected_sale_code}.txt",
                                mime="text/plain",
                                use_container_width=True,
                                help="In a production app, this would generate a PDF receipt"
                            )
            else:
                st.info("No sales match your search criteria")
        else:
            st.info("📝 No sales recorded yet. Record some sales first to generate QR codes.")
    
    # Tab 3: Bulk Download
    with verify_tab3:
        st.markdown("""
        <div class='card'>
            <h4>📱 Bulk QR Code Generator</h4>
            <p>Generate and download multiple QR codes at once</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Get all sales
        sales = data_manager.get_sales()
        
        if sales:
            # Add filter options
            bulk_col1, bulk_col2 = st.columns(2)
            
            with bulk_col1:
                date_range = st.date_input(
                    "Date Range (optional)",
                    value=(datetime.datetime.now() - datetime.timedelta(days=30), datetime.datetime.now()),
                    help="Filter sales by date range"
                )
            
            with bulk_col2:
                status_filter = st.multiselect(
                    "Status Filter",
                    options=["Completed", "Refunded", "Replaced"],
                    default=["Completed"],
                    help="Select which status types to include"
                )
            
            # Apply filters
            filtered_sales = [
                s for s in sales 
                if s.get('status') in status_filter
            ]
            
            if filtered_sales:
                st.write(f"Found {len(filtered_sales)} sales matching your criteria")
                
                # Display a table of sales
                sales_df = pd.DataFrame(filtered_sales)
                
                # Get product names
                products_dict = {p['id']: p['name'] for p in data_manager.get_products()}
                
                # Add product name column
                if 'product_id' in sales_df.columns:
                    sales_df['product'] = sales_df['product_id'].map(products_dict)
                
                # Format currency columns
                if 'amount' in sales_df.columns:
                    sales_df['amount'] = sales_df['amount'].apply(lambda x: format_currency(x))
                
                # Format display columns
                display_cols = ['date', 'sale_code', 'product', 'amount', 'status']
                display_cols = [col for col in display_cols if col in sales_df.columns]
                
                st.dataframe(sales_df[display_cols], use_container_width=True, height=250)
                
                st.markdown("""
                <div class="info-box">
                    <h4>💡 Bulk Download Options</h4>
                    <p>In a production version, the following options would be fully implemented:</p>
                </div>
                """, unsafe_allow_html=True)
                
                bulk_actions_col1, bulk_actions_col2 = st.columns(2)
                
                with bulk_actions_col1:
                    if st.button("📥 Download All QR Codes as ZIP", use_container_width=True):
                        st.info("This would generate a ZIP file with all selected QR codes")
                
                with bulk_actions_col2:
                    if st.button("📊 Generate Sales Report PDF", use_container_width=True):
                        st.info("This would generate a PDF report of all selected sales with QR codes")
            else:
                st.warning("No sales match your filter criteria")
        else:
            st.info("No sales recorded yet")

# Helper function to look up product names
def product_name_lookup(product_id, data_manager):
    product = data_manager.get_product_by_id(product_id)
    return product.get('name', 'Unknown Product') if product else 'Unknown Product'
