import streamlit as st
import pandas as pd
from utils import validate_product_data, generate_id, calculate_profit, format_currency

st.set_page_config(
    page_title="Inventory Management",
    page_icon="📦",
    layout="wide"
)

# Custom styles
st.markdown("""
<style>
    .inventory-header {
        padding: 1rem;
        border-radius: 10px;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
    }
    .card {
        padding: 1.5rem;
        border-radius: 10px;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }
    .success-box {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        color: #856404;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Get data manager from session state
data_manager = st.session_state.data_manager

# Main inventory page
st.markdown("<h1>📦 Inventory Management</h1>", unsafe_allow_html=True)
st.markdown("Manage your digital products inventory, track stock levels, and set pricing")

# Create tabs for different inventory operations
tab1, tab2, tab3 = st.tabs(["📋 Products List", "➕ Add Product", "🔍 Search/Filter"])

# Tab 1: Products List
with tab1:
    st.subheader("Current Inventory")
    
    # Get products
    products = data_manager.get_products()
    
    if products:
        # Convert to DataFrame for better display
        products_df = pd.DataFrame(products)
        
        # Format display columns
        if not products_df.empty:
            display_cols = ['id', 'name', 'description', 'cost_price', 'price', 'profit_margin', 'quantity', 'low_stock_threshold', 'date_added']
            display_cols = [col for col in display_cols if col in products_df.columns]
            
            # Add calculated columns if they don't exist
            if 'cost_price' in products_df.columns and 'price' in products_df.columns:
                # Calculate profit margin percentage
                products_df['profit_margin'] = products_df.apply(
                    lambda row: f"{((row['price'] - row['cost_price']) / row['price'] * 100):.1f}%" 
                    if row['price'] > 0 else "0%", 
                    axis=1
                )
                
                # Format currency columns
                products_df['price'] = products_df['price'].apply(lambda x: format_currency(x))
                if 'cost_price' in products_df.columns:
                    products_df['cost_price'] = products_df['cost_price'].apply(lambda x: format_currency(x))
            
            # Add stock status column
            if 'quantity' in products_df.columns and 'low_stock_threshold' in products_df.columns:
                products_df['stock_status'] = products_df.apply(
                    lambda row: "⚠️ Low" if row['quantity'] <= row['low_stock_threshold'] else "✅ OK", 
                    axis=1
                )
                display_cols.append('stock_status')
            
            # Display the products table
            st.dataframe(products_df[display_cols], use_container_width=True, height=400)
            
            # Product management section
            st.subheader("Manage Product")
            
            # Select product to edit/delete
            product_options = {f"{p['name']} (ID: {p['id']})": p['id'] for p in products}
            selected_product_display = st.selectbox("Select a product", options=list(product_options.keys()))
            
            if selected_product_display:
                selected_product_id = product_options[selected_product_display]
                selected_product = data_manager.get_product_by_id(selected_product_id)
                
                if selected_product:
                    # Display profit information
                    if 'price' in selected_product and 'cost_price' in selected_product:
                        cost_price = selected_product.get('cost_price', 0)
                        sell_price = selected_product.get('price', 0)
                        profit_info = calculate_profit(cost_price, sell_price)
                        
                        profit_col1, profit_col2, profit_col3 = st.columns(3)
                        with profit_col1:
                            st.metric("Unit Profit", format_currency(profit_info['unit_profit']))
                        with profit_col2:
                            st.metric("Profit Margin", f"{profit_info['profit_margin']:.1f}%")
                        with profit_col3:
                            total_value = sell_price * selected_product.get('quantity', 0)
                            st.metric("Total Stock Value", format_currency(total_value))
                    
                    edit_col, delete_col = st.columns(2)
                    
                    with edit_col:
                        st.subheader("Edit Product")
                        
                        # Edit form
                        with st.form(key="edit_product_form"):
                            name = st.text_input("Product Name", value=selected_product.get('name', ''))
                            description = st.text_area("Description", value=selected_product.get('description', ''))
                            cost_price = st.number_input(
                                "Buy Price ($)", 
                                value=float(selected_product.get('cost_price', 0)), 
                                min_value=0.0, 
                                step=0.01
                            )
                            price = st.number_input(
                                "Sell Price ($)", 
                                value=float(selected_product.get('price', 0)), 
                                min_value=0.0, 
                                step=0.01
                            )
                            
                            # Show real-time profit calculation
                            if cost_price > 0 and price > 0:
                                profit = price - cost_price
                                margin = (profit / price * 100) if price > 0 else 0
                                st.info(f"Profit per unit: {format_currency(profit)} (Margin: {margin:.1f}%)")
                                
                            quantity = st.number_input("Quantity", value=int(selected_product.get('quantity', 0)), min_value=0, step=1)
                            low_stock_threshold = st.number_input("Low Stock Alert Threshold", 
                                                                value=int(selected_product.get('low_stock_threshold', 5)), 
                                                                min_value=1, step=1)
                            
                            submit_button = st.form_submit_button("Update Product")
                            
                            if submit_button:
                                updated_data = {
                                    'name': name,
                                    'description': description,
                                    'cost_price': cost_price,
                                    'price': price,
                                    'quantity': quantity,
                                    'low_stock_threshold': low_stock_threshold
                                }
                                
                                # Validate data
                                errors = validate_product_data(updated_data)
                                
                                if errors:
                                    for error in errors:
                                        st.error(error)
                                else:
                                    # Update product
                                    if data_manager.update_product(selected_product_id, updated_data):
                                        st.success("Product updated successfully")
                                        st.rerun()
                                    else:
                                        st.error("Failed to update product")
                    
                    with delete_col:
                        st.subheader("Delete Product")
                        st.warning("This action cannot be undone!")
                        
                        if st.button("Delete Product"):
                            # Check if product has associated sales
                            sales = data_manager.get_sales()
                            product_sales = [s for s in sales if s.get('product_id') == selected_product_id]
                            
                            if product_sales:
                                st.error(f"Cannot delete product with {len(product_sales)} associated sales.")
                            else:
                                if data_manager.delete_product(selected_product_id):
                                    st.success("Product deleted successfully")
                                    st.rerun()
                                else:
                                    st.error("Failed to delete product")
    else:
        st.info("No products in inventory. Add some products to get started.")

# Tab 2: Add Product
with tab2:
    st.subheader("Add New Product")
    
    with st.form(key="add_product_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input("Product Name")
            cost_price = st.number_input("Buy Price ($)", min_value=0.0, step=0.01)
            quantity = st.number_input("Quantity", min_value=0, step=1)
        
        with col2:
            description = st.text_area("Description")
            price = st.number_input("Sell Price ($)", min_value=0.0, step=0.01)
            low_stock_threshold = st.number_input("Low Stock Alert Threshold", min_value=1, value=5, step=1)
        
        # Show real-time profit calculation
        if cost_price > 0 and price > 0:
            profit = price - cost_price
            margin = (profit / price * 100) if price > 0 else 0
            st.info(f"Profit per unit: {format_currency(profit)} (Margin: {margin:.1f}%)")
        
        submit_button = st.form_submit_button("Add Product")
        
        if submit_button:
            new_product = {
                'name': name,
                'description': description,
                'cost_price': cost_price,
                'price': price,
                'quantity': quantity,
                'low_stock_threshold': low_stock_threshold
            }
            
            # Validate data
            errors = validate_product_data(new_product)
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                # Add product
                if data_manager.add_product(new_product):
                    st.success("Product added successfully")
                    # Clear form
                    st.rerun()
                else:
                    st.error("Failed to add product")

# Tab 3: Search/Filter
with tab3:
    st.subheader("Search & Filter Products")
    
    # Get products
    products = data_manager.get_products()
    
    if products:
        search_col1, search_col2 = st.columns(2)
        
        with search_col1:
            search_term = st.text_input("Search by Name or Description")
        
        with search_col2:
            stock_filter = st.selectbox(
                "Filter by Stock Status",
                options=["All", "In Stock", "Low Stock", "Out of Stock"]
            )
        
        # Filter products based on search and filter criteria
        filtered_products = []
        
        for product in products:
            # Search term filter
            if search_term:
                name_match = search_term.lower() in product.get('name', '').lower()
                desc_match = search_term.lower() in product.get('description', '').lower()
                if not (name_match or desc_match):
                    continue
            
            # Stock status filter
            quantity = product.get('quantity', 0)
            low_threshold = product.get('low_stock_threshold', 5)
            
            if stock_filter == "In Stock" and quantity <= 0:
                continue
            elif stock_filter == "Low Stock" and quantity > low_threshold:
                continue
            elif stock_filter == "Out of Stock" and quantity > 0:
                continue
            
            filtered_products.append(product)
        
        # Display filtered results
        if filtered_products:
            st.write(f"Found {len(filtered_products)} products")
            
            # Convert to DataFrame
            filtered_df = pd.DataFrame(filtered_products)
            
            # Format display columns
            display_cols = ['id', 'name', 'description', 'cost_price', 'price', 'profit_margin', 'quantity', 'low_stock_threshold', 'date_added']
            display_cols = [col for col in display_cols if col in filtered_df.columns]
            
            # Add calculated columns
            if 'cost_price' in filtered_df.columns and 'price' in filtered_df.columns:
                # Calculate profit margin percentage
                filtered_df['profit_margin'] = filtered_df.apply(
                    lambda row: f"{((row['price'] - row['cost_price']) / row['price'] * 100):.1f}%" 
                    if row['price'] > 0 else "0%", 
                    axis=1
                )
                
                # Format currency columns
                filtered_df['price'] = filtered_df['price'].apply(lambda x: format_currency(x))
                if 'cost_price' in filtered_df.columns:
                    filtered_df['cost_price'] = filtered_df['cost_price'].apply(lambda x: format_currency(x))
            
            # Add stock status column
            if 'quantity' in filtered_df.columns and 'low_stock_threshold' in filtered_df.columns:
                filtered_df['stock_status'] = filtered_df.apply(
                    lambda row: "⚠️ Low" if row['quantity'] <= row['low_stock_threshold'] else "✅ OK", 
                    axis=1
                )
                display_cols.append('stock_status')
            
            # Display the filtered products table
            st.dataframe(filtered_df[display_cols], use_container_width=True)
        else:
            st.info("No products match your search criteria")
    else:
        st.info("No products in inventory. Add some products to get started.")
