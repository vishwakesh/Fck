import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np

st.set_page_config(
    page_title="Analytics & Reports",
    page_icon="📊",
    layout="wide"
)

# Get data manager from session state
data_manager = st.session_state.data_manager

# Main analytics page
st.title("Analytics & Reports")

# Create tabs for different analytics views
tab1, tab2, tab3 = st.tabs(["Sales Overview", "Product Performance", "Profit Analysis"])

# Helper function to prepare data
def prepare_sales_data():
    sales = data_manager.get_sales()
    products = data_manager.get_products()
    products_dict = {p['id']: p for p in products}
    
    if not sales:
        return pd.DataFrame()
    
    # Convert to DataFrame
    sales_df = pd.DataFrame(sales)
    
    # Ensure date column is in datetime format
    if 'date' in sales_df.columns:
        sales_df['date'] = pd.to_datetime(sales_df['date'])
    
    # Add product name
    if 'product_id' in sales_df.columns:
        sales_df['product_name'] = sales_df['product_id'].apply(
            lambda pid: products_dict.get(pid, {}).get('name', 'Unknown Product')
        )
    
    return sales_df

# Tab 1: Sales Overview
with tab1:
    st.subheader("Sales Overview")
    
    # Get sales data
    sales_df = prepare_sales_data()
    
    if not sales_df.empty:
        # Date filter
        col1, col2 = st.columns(2)
        
        with col1:
            date_range = st.selectbox(
                "Select Time Period",
                options=["Last 7 Days", "Last 30 Days", "Last 90 Days", "This Year", "All Time"]
            )
        
        with col2:
            status_filter = st.multiselect(
                "Filter by Status",
                options=["Completed", "Refunded", "Replaced"],
                default=["Completed"]
            )
        
        # Apply filters
        today = datetime.now().date()
        
        if date_range == "Last 7 Days":
            start_date = today - timedelta(days=7)
        elif date_range == "Last 30 Days":
            start_date = today - timedelta(days=30)
        elif date_range == "Last 90 Days":
            start_date = today - timedelta(days=90)
        elif date_range == "This Year":
            start_date = datetime(today.year, 1, 1).date()
        else:  # All Time
            start_date = pd.to_datetime("1900-01-01").date()
        
        if 'date' in sales_df.columns:
            filtered_df = sales_df[
                (sales_df['date'].dt.date >= start_date) &
                (sales_df['date'].dt.date <= today)
            ]
            
            if status_filter:
                filtered_df = filtered_df[filtered_df['status'].isin(status_filter)]
            
            # Key metrics
            total_sales = len(filtered_df)
            total_revenue = filtered_df['amount'].sum() if 'amount' in filtered_df.columns else 0
            avg_sale_value = total_revenue / total_sales if total_sales > 0 else 0
            
            metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
            
            with metrics_col1:
                st.metric("Total Sales", total_sales)
            
            with metrics_col2:
                st.metric("Total Revenue", f"${total_revenue:.2f}")
            
            with metrics_col3:
                st.metric("Average Sale Value", f"${avg_sale_value:.2f}")
            
            # Sales trend chart
            if 'date' in filtered_df.columns and len(filtered_df) > 0:
                st.subheader("Sales Trend")
                
                # Group by date
                daily_sales = filtered_df.groupby(filtered_df['date'].dt.date).agg({
                    'id': 'count',
                    'amount': 'sum'
                }).reset_index()
                
                daily_sales.columns = ['date', 'count', 'revenue']
                
                # Create trend chart
                fig = px.line(
                    daily_sales,
                    x='date',
                    y='revenue',
                    title="Daily Revenue",
                    labels={'date': 'Date', 'revenue': 'Revenue ($)'}
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Status breakdown
            if 'status' in filtered_df.columns:
                st.subheader("Sales Status Breakdown")
                
                status_counts = filtered_df['status'].value_counts().reset_index()
                status_counts.columns = ['status', 'count']
                
                fig = px.pie(
                    status_counts,
                    values='count',
                    names='status',
                    title="Sales by Status"
                )
                
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.error("Sales data is missing date information")
    else:
        st.info("No sales data available for analysis")

# Tab 2: Product Performance
with tab2:
    st.subheader("Product Performance")
    
    # Get sales and product data
    sales_df = prepare_sales_data()
    products = data_manager.get_products()
    
    if not sales_df.empty and products:
        # Product sales analysis
        if 'product_id' in sales_df.columns and 'amount' in sales_df.columns and 'quantity' in sales_df.columns:
            # Group by product
            product_sales = sales_df.groupby('product_id').agg({
                'id': 'count',
                'quantity': 'sum',
                'amount': 'sum'
            }).reset_index()
            
            product_sales.columns = ['product_id', 'sales_count', 'quantity_sold', 'revenue']
            
            # Add product names
            products_dict = {p['id']: p['name'] for p in products}
            product_sales['product_name'] = product_sales['product_id'].map(products_dict)
            
            # Sort by revenue
            product_sales = product_sales.sort_values('revenue', ascending=False)
            
            # Display top products
            st.subheader("Top Products by Revenue")
            
            top_products = product_sales.head(10)
            
            fig = px.bar(
                top_products,
                x='product_name',
                y='revenue',
                title="Top Products by Revenue",
                labels={'product_name': 'Product', 'revenue': 'Revenue ($)'}
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Product quantity sold
            st.subheader("Products by Quantity Sold")
            
            # Sort by quantity sold
            qty_products = product_sales.sort_values('quantity_sold', ascending=False).head(10)
            
            fig = px.bar(
                qty_products,
                x='product_name',
                y='quantity_sold',
                title="Top Products by Quantity Sold",
                labels={'product_name': 'Product', 'quantity_sold': 'Units Sold'}
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Detailed product performance table
            st.subheader("Detailed Product Performance")
            
            product_table = product_sales[['product_name', 'sales_count', 'quantity_sold', 'revenue']]
            
            # Add average price per unit
            product_table['avg_price_per_unit'] = product_table['revenue'] / product_table['quantity_sold']
            
            # Format table
            product_table['revenue'] = product_table['revenue'].map('${:.2f}'.format)
            product_table['avg_price_per_unit'] = product_table['avg_price_per_unit'].map('${:.2f}'.format)
            
            st.dataframe(product_table, use_container_width=True)
        else:
            st.error("Sales data is missing required columns for product analysis")
    else:
        st.info("No sales or product data available for analysis")

# Tab 3: Profit Analysis
with tab3:
    st.subheader("Profit Analysis")
    
    # Get sales and expenses data
    sales_df = prepare_sales_data()
    expenses = data_manager.get_expenses()
    
    if not sales_df.empty or expenses:
        # Date filter
        date_range = st.selectbox(
            "Select Time Period",
            options=["Last 30 Days", "Last 90 Days", "This Year", "All Time"],
            key="profit_date_range"
        )
        
        # Apply date filter
        today = datetime.now().date()
        
        if date_range == "Last 30 Days":
            start_date = today - timedelta(days=30)
        elif date_range == "Last 90 Days":
            start_date = today - timedelta(days=90)
        elif date_range == "This Year":
            start_date = datetime(today.year, 1, 1).date()
        else:  # All Time
            start_date = pd.to_datetime("1900-01-01").date()
        
        # Calculate revenue
        revenue = 0
        if not sales_df.empty and 'date' in sales_df.columns and 'amount' in sales_df.columns:
            filtered_sales = sales_df[
                (sales_df['date'].dt.date >= start_date) &
                (sales_df['date'].dt.date <= today) &
                (sales_df['status'] != 'Refunded')  # Exclude refunded sales
            ]
            
            revenue = filtered_sales['amount'].sum()
        
        # Calculate expenses
        total_expenses = 0
        if expenses:
            # Convert to DataFrame
            expenses_df = pd.DataFrame(expenses)
            
            if 'date' in expenses_df.columns and 'amount' in expenses_df.columns:
                expenses_df['date'] = pd.to_datetime(expenses_df['date'])
                
                filtered_expenses = expenses_df[
                    (expenses_df['date'].dt.date >= start_date) &
                    (expenses_df['date'].dt.date <= today)
                ]
                
                total_expenses = filtered_expenses['amount'].sum()
        
        # Calculate profit
        profit = revenue - total_expenses
        profit_margin = (profit / revenue * 100) if revenue > 0 else 0
        
        # Display metrics
        metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
        
        with metrics_col1:
            st.metric("Total Revenue", f"${revenue:.2f}")
        
        with metrics_col2:
            st.metric("Total Expenses", f"${total_expenses:.2f}")
        
        with metrics_col3:
            st.metric("Net Profit", f"${profit:.2f}")
        
        with metrics_col4:
            st.metric("Profit Margin", f"{profit_margin:.1f}%")
        
        # Profit chart
        if not sales_df.empty and 'date' in sales_df.columns and 'amount' in sales_df.columns:
            st.subheader("Revenue vs. Expenses")
            
            # Group by date
            daily_sales = sales_df[sales_df['status'] != 'Refunded'].groupby(
                sales_df['date'].dt.date
            )['amount'].sum().reset_index()
            
            daily_sales.columns = ['date', 'revenue']
            
            # Daily expenses
            daily_expenses = pd.DataFrame({'date': [], 'expenses': []})
            
            if expenses and 'date' in expenses_df.columns and 'amount' in expenses_df.columns:
                daily_expenses = expenses_df.groupby(
                    expenses_df['date'].dt.date
                )['amount'].sum().reset_index()
                
                daily_expenses.columns = ['date', 'expenses']
            
            # Merge data
            profit_data = pd.merge(daily_sales, daily_expenses, on='date', how='outer').fillna(0)
            
            # Calculate daily profit
            profit_data['profit'] = profit_data['revenue'] - profit_data['expenses']
            
            # Create chart
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=profit_data['date'],
                y=profit_data['revenue'],
                name='Revenue',
                line=dict(color='green')
            ))
            
            fig.add_trace(go.Scatter(
                x=profit_data['date'],
                y=profit_data['expenses'],
                name='Expenses',
                line=dict(color='red')
            ))
            
            fig.add_trace(go.Scatter(
                x=profit_data['date'],
                y=profit_data['profit'],
                name='Profit',
                line=dict(color='blue')
            ))
            
            fig.update_layout(
                title="Daily Revenue, Expenses and Profit",
                xaxis_title="Date",
                yaxis_title="Amount ($)",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Expense breakdown
            if expenses:
                st.subheader("Expense Breakdown")
                
                # Group by category if available
                if 'category' in expenses_df.columns:
                    expense_cats = expenses_df.groupby('category')['amount'].sum().reset_index()
                    
                    fig = px.pie(
                        expense_cats,
                        values='amount',
                        names='category',
                        title="Expenses by Category"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No financial data available for analysis")
