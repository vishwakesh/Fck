import streamlit as st
import pandas as pd
import io
import os
import json
from utils import export_data_to_csv

st.set_page_config(
    page_title="Settings & Export",
    page_icon="⚙️",
    layout="wide"
)

# Get data manager from session state
data_manager = st.session_state.data_manager

# Main settings page
st.title("Settings & Data Management")

# Create tabs for different settings
tab1, tab2 = st.tabs(["Import/Export Data", "Expense Management"])

# Tab 1: Import/Export Data
with tab1:
    st.subheader("Export Data")
    
    # Export options
    export_col1, export_col2 = st.columns(2)
    
    with export_col1:
        st.write("Export to CSV")
        
        # Export products
        if st.button("Export Products"):
            products = data_manager.get_products()
            
            if products:
                csv_data = export_data_to_csv(products, "products.csv")
                
                st.download_button(
                    label="Download Products CSV",
                    data=csv_data,
                    file_name="products.csv",
                    mime="text/csv"
                )
            else:
                st.warning("No product data to export")
        
        # Export sales
        if st.button("Export Sales"):
            sales = data_manager.get_sales()
            
            if sales:
                csv_data = export_data_to_csv(sales, "sales.csv")
                
                st.download_button(
                    label="Download Sales CSV",
                    data=csv_data,
                    file_name="sales.csv",
                    mime="text/csv"
                )
            else:
                st.warning("No sales data to export")
        
        # Export expenses
        if st.button("Export Expenses"):
            expenses = data_manager.get_expenses()
            
            if expenses:
                csv_data = export_data_to_csv(expenses, "expenses.csv")
                
                st.download_button(
                    label="Download Expenses CSV",
                    data=csv_data,
                    file_name="expenses.csv",
                    mime="text/csv"
                )
            else:
                st.warning("No expense data to export")
    
    with export_col2:
        st.write("Export All Data (JSON)")
        
        # Export all data as JSON
        if st.button("Export All Data"):
            all_data = data_manager.export_all_data()
            
            if all_data:
                json_data = json.dumps(all_data, indent=2)
                
                st.download_button(
                    label="Download All Data (JSON)",
                    data=json_data,
                    file_name="inventory_data.json",
                    mime="application/json"
                )
            else:
                st.warning("No data to export")
    
    st.subheader("Import Data")
    st.warning("Importing data will replace existing data. Make sure to export your current data as a backup.")
    
    import_col1, import_col2 = st.columns(2)
    
    with import_col1:
        st.write("Import Products")
        
        uploaded_products = st.file_uploader("Upload Products CSV", type=["csv"])
        
        if uploaded_products:
            try:
                # Read the CSV file
                products_df = pd.read_csv(uploaded_products)
                
                if st.button("Import Products Data"):
                    # Convert DataFrame to list of dictionaries
                    products_data = products_df.to_dict('records')
                    
                    # Write to products file
                    if data_manager._write_data(data_manager.products_file, products_data):
                        st.success("Products data imported successfully")
                        st.rerun()
                    else:
                        st.error("Failed to import products data")
            except Exception as e:
                st.error(f"Error importing products data: {str(e)}")
    
    with import_col2:
        st.write("Import Sales")
        
        uploaded_sales = st.file_uploader("Upload Sales CSV", type=["csv"])
        
        if uploaded_sales:
            try:
                # Read the CSV file
                sales_df = pd.read_csv(uploaded_sales)
                
                if st.button("Import Sales Data"):
                    # Convert DataFrame to list of dictionaries
                    sales_data = sales_df.to_dict('records')
                    
                    # Write to sales file
                    if data_manager._write_data(data_manager.sales_file, sales_data):
                        st.success("Sales data imported successfully")
                        st.rerun()
                    else:
                        st.error("Failed to import sales data")
            except Exception as e:
                st.error(f"Error importing sales data: {str(e)}")
    
    st.write("Import All Data (JSON)")
    
    uploaded_json = st.file_uploader("Upload All Data JSON", type=["json"])
    
    if uploaded_json:
        try:
            # Read the JSON file
            all_data = json.load(uploaded_json)
            
            if st.button("Import All Data"):
                # Validate data structure
                if not all(key in all_data for key in ['products', 'sales', 'expenses']):
                    st.error("Invalid data format. JSON file must contain 'products', 'sales', and 'expenses' keys.")
                else:
                    # Write products data
                    products_success = data_manager._write_data(data_manager.products_file, all_data['products'])
                    
                    # Write sales data
                    sales_success = data_manager._write_data(data_manager.sales_file, all_data['sales'])
                    
                    # Write expenses data
                    expenses_success = data_manager._write_data(data_manager.expenses_file, all_data['expenses'])
                    
                    if products_success and sales_success and expenses_success:
                        st.success("All data imported successfully")
                        st.rerun()
                    else:
                        st.error("Failed to import all data")
        except Exception as e:
            st.error(f"Error importing data: {str(e)}")

# Tab 2: Expense Management
with tab2:
    st.subheader("Expense Management")
    
    # Create tabs for expense operations
    expense_tab1, expense_tab2 = st.tabs(["Add Expense", "View/Edit Expenses"])
    
    # Tab 1: Add Expense
    with expense_tab1:
        st.write("Record a new expense")
        
        with st.form(key="add_expense_form"):
            description = st.text_input("Description")
            amount = st.number_input("Amount ($)", min_value=0.0, step=0.01)
            
            # Category selection
            category = st.selectbox(
                "Category",
                options=["Software", "Hardware", "Services", "Marketing", "Utilities", "Fees", "Other"]
            )
            
            notes = st.text_area("Notes")
            
            submit_button = st.form_submit_button("Add Expense")
            
            if submit_button:
                if not description:
                    st.error("Description is required")
                elif amount <= 0:
                    st.error("Amount must be greater than 0")
                else:
                    expense_data = {
                        'description': description,
                        'amount': amount,
                        'category': category,
                        'notes': notes
                    }
                    
                    if data_manager.add_expense(expense_data):
                        st.success("Expense recorded successfully")
                        st.rerun()
                    else:
                        st.error("Failed to record expense")
    
    # Tab 2: View/Edit Expenses
    with expense_tab2:
        st.write("View and manage expenses")
        
        # Get expenses
        expenses = data_manager.get_expenses()
        
        if expenses:
            # Convert to DataFrame for better display
            expenses_df = pd.DataFrame(expenses)
            
            # Filter options
            filter_col1, filter_col2 = st.columns(2)
            
            with filter_col1:
                # Category filter
                if 'category' in expenses_df.columns:
                    categories = ["All"] + sorted(expenses_df['category'].unique().tolist())
                    category_filter = st.selectbox("Filter by Category", options=categories)
                else:
                    category_filter = "All"
            
            with filter_col2:
                # Date range filter (if date column exists)
                if 'date' in expenses_df.columns:
                    expenses_df['date'] = pd.to_datetime(expenses_df['date'])
                    
                    date_min = expenses_df['date'].min().date()
                    date_max = expenses_df['date'].max().date()
                    
                    date_range = st.date_input(
                        "Date Range",
                        value=(date_min, date_max),
                        min_value=date_min,
                        max_value=date_max
                    )
                    
                    if len(date_range) == 2:
                        start_date, end_date = date_range
                    else:
                        start_date = end_date = date_range[0]
                else:
                    start_date = end_date = None
            
            # Apply filters
            filtered_expenses = expenses
            
            if category_filter != "All" and 'category' in expenses_df.columns:
                filtered_expenses = [e for e in filtered_expenses if e.get('category') == category_filter]
            
            if start_date and end_date and 'date' in expenses_df.columns:
                filtered_expenses = [
                    e for e in filtered_expenses if 
                    pd.to_datetime(e.get('date')).date() >= start_date and 
                    pd.to_datetime(e.get('date')).date() <= end_date
                ]
            
            # Display expenses
            if filtered_expenses:
                filtered_df = pd.DataFrame(filtered_expenses)
                
                display_cols = ['id', 'date', 'description', 'category', 'amount', 'notes']
                display_cols = [col for col in display_cols if col in filtered_df.columns]
                
                st.dataframe(filtered_df[display_cols], use_container_width=True)
                
                # Expense details and management
                st.subheader("Manage Expense")
                
                # Select expense to edit/delete
                expense_options = {f"{e.get('description', 'N/A')} - ${e.get('amount', 0):.2f}": e['id'] for e in filtered_expenses}
                selected_expense_display = st.selectbox("Select an expense", options=list(expense_options.keys()))
                
                if selected_expense_display:
                    selected_expense_id = expense_options[selected_expense_display]
                    selected_expense = next((e for e in expenses if e.get('id') == selected_expense_id), None)
                    
                    if selected_expense:
                        edit_col, delete_col = st.columns(2)
                        
                        with edit_col:
                            st.subheader("Edit Expense")
                            
                            with st.form(key="edit_expense_form"):
                                edit_description = st.text_input("Description", value=selected_expense.get('description', ''))
                                edit_amount = st.number_input("Amount ($)", value=float(selected_expense.get('amount', 0)), min_value=0.0, step=0.01)
                                
                                # Category selection
                                edit_category = st.selectbox(
                                    "Category",
                                    options=["Software", "Hardware", "Services", "Marketing", "Utilities", "Fees", "Other"],
                                    index=["Software", "Hardware", "Services", "Marketing", "Utilities", "Fees", "Other"].index(selected_expense.get('category', 'Other'))
                                )
                                
                                edit_notes = st.text_area("Notes", value=selected_expense.get('notes', ''))
                                
                                update_button = st.form_submit_button("Update Expense")
                                
                                if update_button:
                                    if not edit_description:
                                        st.error("Description is required")
                                    elif edit_amount <= 0:
                                        st.error("Amount must be greater than 0")
                                    else:
                                        updated_data = {
                                            'description': edit_description,
                                            'amount': edit_amount,
                                            'category': edit_category,
                                            'notes': edit_notes
                                        }
                                        
                                        if data_manager.update_expense(selected_expense_id, updated_data):
                                            st.success("Expense updated successfully")
                                            st.rerun()
                                        else:
                                            st.error("Failed to update expense")
                        
                        with delete_col:
                            st.subheader("Delete Expense")
                            st.warning("This action cannot be undone!")
                            
                            if st.button("Delete Expense"):
                                if data_manager.delete_expense(selected_expense_id):
                                    st.success("Expense deleted successfully")
                                    st.rerun()
                                else:
                                    st.error("Failed to delete expense")
            else:
                st.info("No expenses match your filter criteria")
        else:
            st.info("No expenses recorded yet")
