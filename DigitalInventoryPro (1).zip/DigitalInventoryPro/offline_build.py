"""
This script would be used to build the offline version of the application using PyInstaller.
In a real application, this would create an executable that includes all the necessary
dependencies and can run without an internet connection.

This is not meant to be run directly in the Streamlit app, but is included to show how
the offline version would be created.
"""

import sys
import os
import platform
import subprocess

def build_offline_app():
    """
    Build the offline version of the application using PyInstaller
    """
    print("Building offline version of DigitalStock...")
    
    # Determine current platform
    current_os = platform.system()
    
    # Define PyInstaller command
    pyinstaller_cmd = [
        'pyinstaller',
        '--name=DigitalStock',
        '--onefile',
        '--windowed',  # GUI mode, no console
        '--add-data=app_data:app_data',  # Include the data directory
    ]
    
    # Add OS-specific options
    if current_os == 'Windows':
        pyinstaller_cmd.extend(['--icon=icon.ico'])
    elif current_os == 'Darwin':  # macOS
        pyinstaller_cmd.extend(['--icon=icon.icns'])
    
    # Add main script
    pyinstaller_cmd.append('app.py')
    
    # Execute PyInstaller
    try:
        subprocess.run(pyinstaller_cmd, check=True)
        print("Build completed successfully!")
        
        # Determine output file location
        if current_os == 'Windows':
            output_file = 'dist/DigitalStock.exe'
        elif current_os == 'Darwin':  # macOS
            output_file = 'dist/DigitalStock.app'
        else:  # Linux
            output_file = 'dist/DigitalStock'
        
        print(f"Offline application created at: {os.path.abspath(output_file)}")
        return os.path.abspath(output_file)
    
    except subprocess.CalledProcessError as e:
        print(f"Build failed: {e}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

if __name__ == "__main__":
    build_offline_app()
