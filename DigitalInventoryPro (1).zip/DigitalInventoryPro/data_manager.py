import json
import os
import pandas as pd
import streamlit as st
from utils import generate_id, get_current_date

class DataManager:
    def __init__(self):
        """Initialize the data manager with default data directories"""
        # Define data directories and files
        self.data_dir = "app_data"
        self.products_file = os.path.join(self.data_dir, "products.json")
        self.sales_file = os.path.join(self.data_dir, "sales.json")
        self.expenses_file = os.path.join(self.data_dir, "expenses.json")
        
        # Ensure data directory exists
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Initialize data structures if they don't exist
        self._initialize_data_files()
    
    def _initialize_data_files(self):
        """Initialize data files if they don't exist"""
        # Initialize products file
        if not os.path.exists(self.products_file):
            with open(self.products_file, 'w') as f:
                json.dump([], f)
        
        # Initialize sales file
        if not os.path.exists(self.sales_file):
            with open(self.sales_file, 'w') as f:
                json.dump([], f)
        
        # Initialize expenses file
        if not os.path.exists(self.expenses_file):
            with open(self.expenses_file, 'w') as f:
                json.dump([], f)
    
    def _read_data(self, file_path):
        """Read data from a JSON file"""
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            st.error(f"Error reading data: {str(e)}")
            return []
    
    def _write_data(self, file_path, data):
        """Write data to a JSON file"""
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            st.error(f"Error writing data: {str(e)}")
            return False
    
    # Product management
    def get_products(self):
        """Get all products"""
        return self._read_data(self.products_file)
    
    def get_product_by_id(self, product_id):
        """Get a product by ID"""
        products = self.get_products()
        for product in products:
            if product.get('id') == product_id:
                return product
        return None
    
    def add_product(self, product_data):
        """Add a new product"""
        products = self.get_products()
        
        # Create a new product with ID
        new_product = {
            'id': generate_id(),
            'date_added': get_current_date(),
            **product_data
        }
        
        products.append(new_product)
        return self._write_data(self.products_file, products)
    
    def update_product(self, product_id, updated_data):
        """Update an existing product"""
        products = self.get_products()
        
        for i, product in enumerate(products):
            if product.get('id') == product_id:
                # Update the product with new data
                products[i] = {**product, **updated_data}
                return self._write_data(self.products_file, products)
        
        return False
    
    def delete_product(self, product_id):
        """Delete a product"""
        products = self.get_products()
        updated_products = [p for p in products if p.get('id') != product_id]
        
        if len(updated_products) < len(products):
            return self._write_data(self.products_file, updated_products)
        
        return False
    
    def update_stock(self, product_id, quantity_change):
        """Update stock quantity for a product"""
        product = self.get_product_by_id(product_id)
        
        if product:
            current_quantity = product.get('quantity', 0)
            new_quantity = current_quantity + quantity_change
            
            # Ensure quantity doesn't go below 0
            if new_quantity < 0:
                new_quantity = 0
                
            return self.update_product(product_id, {'quantity': new_quantity})
        
        return False
    
    # Sales management
    def get_sales(self):
        """Get all sales"""
        return self._read_data(self.sales_file)
    
    def add_sale(self, sale_data):
        """Add a new sale"""
        sales = self.get_sales()
        
        # Create a new sale with ID
        new_sale = {
            'id': generate_id(),
            'date': get_current_date(),
            **sale_data
        }
        
        sales.append(new_sale)
        success = self._write_data(self.sales_file, sales)
        
        # Update product stock
        if success:
            self.update_stock(sale_data['product_id'], -sale_data['quantity'])
        
        return success
    
    def update_sale(self, sale_id, updated_data):
        """Update an existing sale"""
        sales = self.get_sales()
        
        for i, sale in enumerate(sales):
            if sale.get('id') == sale_id:
                # Handle stock adjustments if quantity changed
                if 'quantity' in updated_data and updated_data['quantity'] != sale['quantity']:
                    quantity_diff = updated_data['quantity'] - sale['quantity']
                    self.update_stock(sale['product_id'], -quantity_diff)
                
                # Update the sale with new data
                sales[i] = {**sale, **updated_data}
                return self._write_data(self.sales_file, sales)
        
        return False
    
    def delete_sale(self, sale_id):
        """Delete a sale"""
        sales = self.get_sales()
        sale_to_delete = None
        
        for sale in sales:
            if sale.get('id') == sale_id:
                sale_to_delete = sale
                break
        
        if sale_to_delete:
            # Restore stock
            self.update_stock(sale_to_delete['product_id'], sale_to_delete['quantity'])
            
            # Remove sale
            updated_sales = [s for s in sales if s.get('id') != sale_id]
            return self._write_data(self.sales_file, updated_sales)
        
        return False
    
    # Expense management
    def get_expenses(self):
        """Get all expenses"""
        return self._read_data(self.expenses_file)
    
    def add_expense(self, expense_data):
        """Add a new expense"""
        expenses = self.get_expenses()
        
        # Create a new expense with ID
        new_expense = {
            'id': generate_id(),
            'date': get_current_date(),
            **expense_data
        }
        
        expenses.append(new_expense)
        return self._write_data(self.expenses_file, expenses)
    
    def update_expense(self, expense_id, updated_data):
        """Update an existing expense"""
        expenses = self.get_expenses()
        
        for i, expense in enumerate(expenses):
            if expense.get('id') == expense_id:
                # Update the expense with new data
                expenses[i] = {**expense, **updated_data}
                return self._write_data(self.expenses_file, expenses)
        
        return False
    
    def delete_expense(self, expense_id):
        """Delete an expense"""
        expenses = self.get_expenses()
        updated_expenses = [e for e in expenses if e.get('id') != expense_id]
        
        if len(updated_expenses) < len(expenses):
            return self._write_data(self.expenses_file, updated_expenses)
        
        return False
    
    # Data import/export
    def import_data_from_json(self, file_path, data_type):
        """Import data from a JSON file"""
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            if data_type == 'products':
                target_file = self.products_file
            elif data_type == 'sales':
                target_file = self.sales_file
            elif data_type == 'expenses':
                target_file = self.expenses_file
            else:
                return False
            
            return self._write_data(target_file, data)
        except Exception as e:
            st.error(f"Error importing data: {str(e)}")
            return False
    
    def import_data_from_csv(self, file_content, data_type):
        """Import data from a CSV file"""
        try:
            df = pd.read_csv(file_content)
            data = df.to_dict('records')
            
            if data_type == 'products':
                target_file = self.products_file
            elif data_type == 'sales':
                target_file = self.sales_file
            elif data_type == 'expenses':
                target_file = self.expenses_file
            else:
                return False
            
            return self._write_data(target_file, data)
        except Exception as e:
            st.error(f"Error importing data: {str(e)}")
            return False
    
    def export_all_data(self):
        """Export all data as a dictionary"""
        return {
            'products': self.get_products(),
            'sales': self.get_sales(),
            'expenses': self.get_expenses()
        }
