import streamlit as st
import os
import sys
import platform
import subprocess
import time

def build_offline_app():
    """
    Simulate building an offline app with PyInstaller
    In a real implementation, this would compile the app for the user's platform
    """
    # In a real implementation, we'd detect the platform and build accordingly
    current_platform = platform.system()
    
    # Simulate building process
    st.write("Starting build process...")
    
    # Show progress bar to simulate build process
    progress_bar = st.progress(0)
    for i in range(101):
        progress_bar.progress(i)
        time.sleep(0.05)
    
    st.success(f"Build completed for {current_platform}")
    
    # In a real implementation, we'd return the path to the executable
    # For this demo, we'll just return a placeholder
    if current_platform == "Windows":
        return "digitalstock.exe"
    else:
        return "digitalstock"

def main():
    st.title("Download Offline Version")
    st.write("Generate and download the offline version of DigitalStock")
    
    st.info("""
    This page demonstrates the concept of building an offline version of the application.
    
    In a real implementation:
    1. The app would use PyInstaller to package all dependencies and create an executable
    2. The build would be specific to the user's operating system
    3. The user would download an actual executable file
    """)
    
    if st.button("Build Offline Version"):
        with st.spinner("Building offline app..."):
            # In a real implementation, this would actually build the app
            # For demo purposes, we're just simulating the process
            executable_name = build_offline_app()
            
            # In a real implementation, we'd provide the actual executable for download
            st.success(f"Build completed! Click below to download {executable_name}")
            
            # This would be replaced with the actual executable in a real implementation
            st.download_button(
                label=f"Download {executable_name}",
                data="This is a placeholder for the actual executable file",
                file_name=executable_name,
                mime="application/octet-stream"
            )
    
    st.markdown("---")
    st.subheader("Offline Usage Instructions")
    st.write("""
    1. Download the executable file for your operating system
    2. Save it to a location on your computer
    3. Run the executable to start the offline version
    4. Your data will be stored locally on your computer
    5. You can import/export data between the web and offline versions
    """)
    
    st.markdown("---")
    st.subheader("💝 Support This Project")
    st.write("Your contributions help maintain and improve DigitalStock")
    
    # Create tabs for different payment methods
    pay_tab1, pay_tab2 = st.tabs(["📱 UPI Payment", "💰 Litecoin (LTC)"])
    
    with pay_tab1:
        st.markdown("""
        ### UPI Payment
        
        Make an instant payment using any UPI app by scanning the QR code or manually entering:
        
        **UPI ID:** `vishwakesh@fam`
        """)
        
        # Add a copy button that works with JavaScript
        st.markdown("""
        <div style="display: flex; align-items: center;">
            <code style="background: #f0f0f0; padding: 0.5rem; border-radius: 5px; margin-right: 0.5rem; font-size: 1.1rem;">vishwakesh@fam</code>
            <button onclick="navigator.clipboard.writeText('vishwakesh@fam'); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy', 2000)" 
            style="background-color: #5e72e4; color: white; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer;">
            Copy UPI ID
            </button>
        </div>
        """, unsafe_allow_html=True)
    
    with pay_tab2:
        st.markdown("""
        ### Litecoin (LTC)
        
        **Litecoin (LTC):** `ltc1qrgjan6957e5zedad88nraht98vw6g8tnneps2c`
        """)
        
        # Add a copy button that works with JavaScript
        st.markdown("""
        <div style="display: flex; align-items: center;">
            <code style="background: #f0f0f0; padding: 0.5rem; border-radius: 5px; margin-right: 0.5rem; font-size: 1.1rem;">ltc1qrgjan6957e5zedad88nraht98vw6g8tnneps2c</code>
            <button onclick="navigator.clipboard.writeText('ltc1qrgjan6957e5zedad88nraht98vw6g8tnneps2c'); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy', 2000)" 
            style="background-color: #5e72e4; color: white; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer;">
            Copy LTC Address
            </button>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        For support, please contact:
        
        **Email:** vishwakesh55@gmail.com
        
        **Discord:** vishwakesh2
        """)
        
    st.markdown("""
    <div style="background-color: #e8f4f8; padding: 1rem; border-radius: 10px; margin-top: 1rem; text-align: center;">
        <h4>Thank You For Your Support! 💖</h4>
        <p>Your contribution helps us improve the application.</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
